
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.content.Context;
import android.Manifest;
import android.widget.Button;
import android.view.View;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.idkwhathappened.R;


public class InventoryActivity extends AppCompatActivity {


    private SQLiteDatabase db;
    private SQLiteOpenHelper dbHelper;
    private EditText itemName, itemQuantity;
    private GridView gridView;
    private SimpleCursorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new inventoryDBHelper(this);
        db = dbHelper.getWritableDatabase();

        itemName = findViewById(R.id.item_name);
        itemQuantity = findViewById(R.id.item_quantity);
        gridView = findViewById(R.id.grid_view);

        Button addButton = findViewById(R.id.add_button);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItem();
                displayItems();
            }
        });

        displayItems();
    }

    private void addItem() {
        String name = itemName.getText().toString();
        int quantity = Integer.parseInt(itemQuantity.getText().toString());
        db.execSQL("INSERT INTO inventory (name, quantity) VALUES (?, ?)", new Object[]{name, quantity});
    }

    private void displayItems() {
        Cursor cursor = db.rawQuery("SELECT * FROM inventory", null);
        String[] from = {"name", "quantity"};
        int[] to = {R.id.item_name, R.id.item_quantity};
        adapter = new SimpleCursorAdapter(this, R.layout.grid_item, cursor, from, to, 0);
        gridView.setAdapter(adapter);
    }
}
