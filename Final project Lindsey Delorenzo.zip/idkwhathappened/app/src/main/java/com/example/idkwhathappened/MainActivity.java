package com.example.idkwhathappened;

import android.content.ContentValues;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.EditText;
import android.widget.Toast;
import android.database.sqlite.SQLiteDatabase;

public class MainActivity extends AppCompatActivity {

    private EditText UsernameLogin, PasswordLogin;
    private Button login_button, create_account_button;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        UsernameLogin = findViewById(R.id.UsernameLogin);
        PasswordLogin = findViewById(R.id.PasswordLogin);
        login_button = findViewById(R.id.login_button);
        create_account_button = findViewById(R.id.create_account_button);

        // Initialize User database
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        db = dbHelper.getWritableDatabase();

        login_button.setOnClickListener(view -> loginUser());
        create_account_button.setOnClickListener(view -> registerUser());
    }

    private void loginUser() {
        String username = UsernameLogin.getText().toString();
        String password = PasswordLogin.getText().toString();

        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username=? AND password=?",
                new String[]{username, password});
        if (cursor.moveToFirst()) {
            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
        }
        cursor.close();
    }

    private void registerUser() {
        String username = UsernameLogin.getText().toString();
        String password = PasswordLogin.getText().toString();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        long result = db.insert("users", null, values);
        if (result == -1) {
            Toast.makeText(this, "Registration Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "User Registered Successfully", Toast.LENGTH_SHORT).show();
        }
    }
}